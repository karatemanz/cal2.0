import RPi.GPIO as GPIO
# fast reading data
import numpy as np
import matplotlib.pyplot as plt
import spidev
import time
import os
from pylab import *
# Define sensor channel
ADT = 0
Test = 1
Vref = 5.0
Solenoid_Pin_1 = 21

# Set up Solenoid pins
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(Solenoid_Pin_1, GPIO.OUT)
GPIO.output(Solenoid_Pin_1, GPIO.LOW)


# Open SPI bus
spi = spidev.SpiDev()
spi.open(0,0)

AMP = 0
POT = 1
TEST = 2

def ReadChannel_12bit(channel):
	#adc = spi.xfer2([(6 + (channel >> 2)), ((channel &3) << 6), 0])
	adc = spi.xfer2([4 | 2 | (channel >> 2), (channel & 3) << 6, 0])
	data = ((adc[1] & 15)<< 8) + adc[2]
	return data

def ReadChannel_10bit(channel):
	# When using MCP3008(10 bit adc)
	adc = spi.xfer2([1,(8+channel)<<4,0])
	data = ((adc[1]&3) << 8) + adc[2]
	return data

def ConvertVolts_12bit(data, places):
	# When using MCP3208(12 bit adc)
	volts = (data*Vref)/float(4096)
	volts = round(volts, places)
	return volts


def solenoid():
	while True:
		state = raw_input('gan ha ya?')
		if state == "on":
			GPIO.output(Solenoid_Pin_1, GPIO.HIGH)

			
		elif state == "off":
			GPIO.output(Solenoid_Pin_1, GPIO.LOW)
			
		
		elif state == "read":
			#data1 = ReadChannel_12bit(AMP)
			#data2 = ReadChannel_12bit(POT)
			#data3 = ReadChannel_12bit(TEST)
			#print data1, data2, data3
			print GPIO.input(Solenoid_Pin_1)
			#print ConvertVolts_12bit(data, 4)
		elif state == "end":
			return 
solenoid()