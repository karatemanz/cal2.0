import wx
import wx.lib.intctrl
class TabPanel(wx.Panel):
	def __init__(self, parent):

		wx.Panel.__init__(self, parent=parent, id=wx.ID_ANY)
		self.frame = parent

		self.MainSizer = wx.BoxSizer(wx.VERTICAL)
		self.sizer1 = wx.BoxSizer(wx.HORIZONTAL)
		self.sizer2 = wx.BoxSizer(wx.HORIZONTAL)
		self.sizer3 = wx.BoxSizer(wx.HORIZONTAL)
		self.sizer4 = wx.BoxSizer(wx.HORIZONTAL)
		self.sizer5 = wx.BoxSizer(wx.HORIZONTAL)

		self.ST = '0'
		self.Start_Temp = wx.StaticText(self, label = "Start Temperature :") 
		self.ST_Input = wx.StaticText(self, label = self.ST)
		self.Start_Temp_Unit = wx.StaticText(self, label = "  C") 


		self.HoldValveText = wx.StaticText(self, label = "Hold valve to A1 (Currently No):") 
		self.HoldValve = wx.CheckBox(self, label = 'Yes')
		self.HoldValve.Bind(wx.EVT_CHECKBOX,self.onChecked)


		self.End_Temp = wx.StaticText(self, label = "End Temperature: ")
		self.ET = wx.lib.intctrl.IntCtrl(self, 131, 20, size=(40, -1),style=wx.TE_RIGHT)
		self.End_Temp_Unit = wx.StaticText(self, label = "C")

		self.Sampling_Rate = wx.StaticText(self, label = "Temperature Sampling rate: ") 
		self.SR = wx.lib.intctrl.IntCtrl(self, 132, 0, size=(30, -1),style=wx.TE_RIGHT)
		self.SR_Unit = wx.StaticText(self, label = "HZ")

		self.upDate = wx.Button(self, label="Update", size=(-1, 20))


		self.sizer1.Add(self.Start_Temp, flag=wx.LEFT|wx.TOP|wx.BOTTOM, border=3)
		self.sizer1.Add(self.ST_Input, flag=wx.LEFT|wx.TOP|wx.BOTTOM, border=3)
		self.sizer1.Add(self.Start_Temp_Unit, flag=wx.LEFT|wx.TOP|wx.BOTTOM, border=3)

		self.sizer5.Add(self.HoldValveText,flag=wx.LEFT|wx.TOP|wx.BOTTOM, border=3)
		self.sizer5.Add(self.HoldValve,flag=wx.LEFT|wx.TOP|wx.BOTTOM, border=3)
		
		self.sizer2.Add(self.End_Temp, flag=wx.LEFT|wx.TOP|wx.BOTTOM, border=3)
		self.sizer2.Add(self.ET)
		self.sizer2.Add(self.End_Temp_Unit, flag=wx.LEFT|wx.TOP|wx.BOTTOM, border=3)
		
		self.sizer3.Add(self.Sampling_Rate, flag=wx.LEFT|wx.TOP|wx.BOTTOM, border=3)
		self.sizer3.Add(self.SR, flag=wx.LEFT|wx.TOP|wx.BOTTOM, border=3)
		self.sizer3.Add(self.SR_Unit, flag=wx.LEFT|wx.TOP, border=7)
		self.sizer4.Add(self.upDate, flag = wx.LEFT, border= 90)

		self.MainSizer.Add(self.sizer1)
		self.MainSizer.Add(self.sizer5)
		self.MainSizer.Add(self.sizer2)
		self.MainSizer.Add(self.sizer3)
		self.MainSizer.Add(self.sizer4)
		self.SetSizer(self.MainSizer)
	def onChecked(self,event):
		checkvalue = event.GetEventObject()
		if checkvalue.GetValue():
			self.HoldValveText.SetLabel("Hold valve to A1 (Currently Yes):")
			self.A1_Temp = wx.lib.intctrl.IntCtrl(self, 132, 0, size=(40, -1),style=wx.TE_RIGHT)
			self.A1_Temp_Unit = wx.StaticText(self, label = "C")			
			self.sizer5.Add(self.A1_Temp, flag=wx.LEFT|wx.TOP|wx.BOTTOM, border=3)
			self.sizer5.Add(self.A1_Temp_Unit, flag=wx.LEFT|wx.TOP, border=7)
			self.SetSizer(self.MainSizer)
			self.frame.Fit()
		else:
			self.HoldValveText.SetLabel("Hold valve to A1 (Currently No):")
			self.sizer5.Hide(self.A1_Temp_Unit)
			self.sizer5.Hide(self.A1_Temp)
			self.sizer5.Remove(self.A1_Temp)
			self.sizer5.Remove(self.A1_Temp_Unit)
			self.SetSizer(self.MainSizer)
			self.A1_Temp = None
			self.A1_Temp_Unit = None
			self.frame.Fit()




class MyFrame(wx.Frame):
    """"""
 
    #----------------------------------------------------------------------
    def __init__(self):
        """Constructor"""
        wx.Frame.__init__(self, parent=None, title="Cooling Setting")
        panel = TabPanel(self)
        self.Show()
        
#----------------------------------------------------------------------
if __name__ == "__main__":
    app = wx.App()
    frame = MyFrame()
    app.MainLoop()
